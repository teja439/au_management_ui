export interface BatchSchema {
  batchName: String,
  startDate: Date,
  endDate: Date,
  commonSkypeId: String
}
