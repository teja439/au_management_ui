export interface trainerSchema {
  TrainerName: String,
  BusinessUnit:String,
  SkypeId : String,
  EmailId: String,
  ReportingManagerEmail: String
}
