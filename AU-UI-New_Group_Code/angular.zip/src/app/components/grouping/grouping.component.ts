import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import {MatDialog, MatDialogConfig, MatDialogRef, } from '@angular/material/dialog';
import { CreateGroupComponent } from '../create-group/create-group.component';

@Component({
  selector: 'app-grouping',
  templateUrl: './grouping.component.html',
  styleUrls: ['./grouping.component.css']
})
export class GroupingComponent implements OnInit {
  panelOpenState = false;
   groups=[];
  constructor(private dialog: MatDialog,private http:HttpClient) { }
  @Input()
  batchId:number
  ngOnInit(): void {
    this.http.get<any[]>('api/group/all?batchId='+this.batchId).subscribe((res) => {
      res.map((item)=>{
          this.groups.push(item)
      })
  })
   console.log(this.groups);
}
 
  openDialog() {
    console.log(this.batchId);
    console.log("hello");
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = false;
    dialogConfig.autoFocus = true;
    dialogConfig.height = '450px';
    dialogConfig.width = '400px';
    dialogConfig.hasBackdrop = true;

    this.dialog.open(CreateGroupComponent, {
      data: {
        batchId: this.batchId,
        
    }});

   
  }
  

}
