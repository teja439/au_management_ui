export interface CSVRecord{
   firstName: String,
   lastName: String,
   email: String,
}
